import pandas as pd
import matplotlib
from numpy import *
from sklearn import *
from scipy import stats
import nltk
#nltk.download('punkt')
#nltk.download('stopwords')
#nltk.download('averaged_perceptron_tagger')
#nltk.download('wordnet')
#nltk.download('omw-1.4')
#df=pd.read_csv('West Nile virus_100.csv')
#print(df.columns)
#abstract_list=df['abstract']
#print(abs_list[0])
from nltk.corpus import wordnet
from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()
from nltk.stem import PorterStemmer
stemmer = PorterStemmer()
from nltk.corpus import stopwords
Extend_stop_words = stopwords.words('english') 
my_stop_word=['.',',','(',')','\'s']
Extend_stop_words.extend(my_stop_word)

def get_wordnet_pos(tag):
    if tag.startswith('J'):
        return wordnet.ADJ
    elif tag.startswith('V'):
        return wordnet.VERB
    elif tag.startswith('N'):
        return wordnet.NOUN
    elif tag.startswith('R'):
        return wordnet.ADV
    else:
        return None
def return_token(text):
    tokens = nltk.word_tokenize(text)
    Tagging=nltk.pos_tag(tokens) 
    lemma_pos_tokens=[]
    for i,token in enumerate(tokens):# lemma with Pos
      pos=Tagging[i][1]
      wordnet_pos = get_wordnet_pos(pos) or wordnet.NOUN
      lmtoken=lemmatizer.lemmatize(token,pos= wordnet_pos)
      lemma_pos_tokens.append(lmtoken)
    tokens=lemma_pos_tokens
    lemma_Stem_tokens = []
    for i,token in enumerate(tokens):#stem with 
        lmsttoken=stemmer.stem(token)
        lemma_Stem_tokens.append(lmsttoken)
    filtered_token_extended = [w for w in lemma_Stem_tokens if(w not in Extend_stop_words)]
    token_to_STR=''
    for token in filtered_token_extended:
         token_to_STR= token_to_STR+' '+str(token)
    return  token_to_STR

def return_token_list(text):
    tokens = nltk.word_tokenize(text)
    Tagging=nltk.pos_tag(tokens) 
    lemma_pos_tokens=[]
    for i,token in enumerate(tokens):# lemma with Pos
      pos=Tagging[i][1]
      wordnet_pos = get_wordnet_pos(pos) or wordnet.NOUN
      lmtoken=lemmatizer.lemmatize(token,pos= wordnet_pos)
      lemma_pos_tokens.append(lmtoken)
    tokens=lemma_pos_tokens
    lemma_Stem_tokens = []
    for i,token in enumerate(tokens):#stem with 
        lmsttoken=stemmer.stem(token)
        lemma_Stem_tokens.append(lmsttoken)
    filtered_token_extended = [w for w in lemma_Stem_tokens if(w not in Extend_stop_words)]
    return filtered_token_extended
#text=abstract_list[0]
#print((return_token(text.lower())))

