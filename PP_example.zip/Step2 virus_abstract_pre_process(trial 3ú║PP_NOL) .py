import pandas as pd
import re
import requests
import os
df=pd.read_csv('Respiratory syncytial virus_100.csv')
print(df.columns)
import time
def delay(sec):
    time.sleep(sec)
keyword_list=['Respiratory syncytial virus']
#df['label'].values.tolist()
#print(keyword_list[0])
#
#print(df2.columns)
#abstract=df2['abstract']
#for abst in abstract:
def printPath(path):  
    global allFileNum 
    fileList = []
    files = os.listdir(path)
    for f in files:
        if(os.path.isfile(path + '/' + f)):  
            # 添加文件  
            fileList.append(f)
    #print(fileList)
    return fileList

def return_file(keywords):
  global flist
  match=0
  for i in range(0,len(flist)):
    if keywords in flist[i]:
       #print('match',keywords,flist[i])
       match=1
       return flist[i]
    if i==len(flist)-1 and match==0:
        print('no match return None')
        return None
from pp import return_token_list

def vectoriz(keywords,df2,upper):
    abstract=df2['abstract']
    merged_abs=[]
    count=0
    if upper<=len(df2):
       for j in range(0,upper):
           if len(str(abstract[j]))!=0:
               try:
                  merged_abs=merged_abs+return_token_list(abstract[j].lower())
               except:
                     try:
                      merged_abs=merged_abs+return_token_list(abstract[j])
                     except:
                        continue
               count+=1
    elif upper>=len(df2):
       for k in range(0,len(df2)):
               if len(str(abstract[k]))!=0:
                  try:
                     merged_abs=merged_abs+return_token_list(abstract[k].lower())
                  except:
                     try:
                         merged_abs=merged_abs+return_token_list(abstract[k])
                     except:
                        continue
                  count+=1
    
    merged_abs=list(set(merged_abs))
    pure_merged_ans_NOL=''#non overlapped 
    for item in merged_abs:
        pure_merged_ans_NOL= pure_merged_ans_NOL+' '+re.sub('[\u4e00-\u9fa5]', '', str(item))
    key={'keywords':keywords,'abs_count':count,'abs_upper':upper,'merged_abs':pure_merged_ans_NOL}
    return key

global flist
flist=printPath('./')
key_list=[]#
upper=100
for token in range(0,len(keyword_list)):
 print(token,keyword_list[token])
 keywords=keyword_list[token]
 filename='Respiratory syncytial virus_100.csv'
 df_temp=pd.read_csv(filename)
 key_back=vectoriz(keywords,df_temp,upper=upper)
 key_list.append(key_back)
kl=pd.DataFrame(key_list)
kl.to_csv('./merged_abstract (预处理 no repeat)/abstract_PPNoL_vir{}_{}Xabs{}.csv'.format(len(key_list),keyword_list[0],upper),index=None)
   
